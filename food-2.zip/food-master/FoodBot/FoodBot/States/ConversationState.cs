﻿namespace FoodBot.States
{
    public enum ConversationState
    {
        None,

        Registration,

        Geo,
        FIO,
        Sx,
        Years,

        Allergy

    }
}